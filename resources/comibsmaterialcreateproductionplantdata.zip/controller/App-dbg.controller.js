sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.ibs.materialcreate.productionplantdata.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  