sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.ibs.materialcreate.procurmentdata.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  